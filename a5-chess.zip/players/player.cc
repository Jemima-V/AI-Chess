#include <string.h>
//#include <vector.h>
#include "game.h"
#include "pieces.h"
#include "player.h"

 //constructor 
Player::Player(string name) : name{name} {}

//void Player::randGenerator() {}

//destructor 
Player::~Player() {}
